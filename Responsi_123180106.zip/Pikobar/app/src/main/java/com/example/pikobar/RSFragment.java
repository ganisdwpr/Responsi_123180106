package com.example.pikobar;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pikobar.API.ApiListener;
import com.example.pikobar.API.ApiService;
import com.example.pikobar.Adapter.RSAdapter;
import com.example.pikobar.Models.RS.RSContent;

import java.util.ArrayList;
import java.util.List;

public class RSFragment extends Fragment {

    RecyclerView rvRS;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_rs, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rvRS = view.findViewById(R.id.rvRS);
        new ApiService().getRS(RSListener);
    }

    ApiListener<List<RSContent>> RSListener = new ApiListener<List<RSContent>>(){

        @Override
        public void onSuccess(List<RSContent> items) {

            ArrayList<RSContent> data = new ArrayList<>();

            for(int i = 0; i < items.size(); i++){
                if(!items.get(i).getNama().contains("Qualifying")){
                    data.add(items.get(i));
                }
                Log.d("RS : ", items.get(i).getNama());
            }

            final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
            linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            rvRS.setLayoutManager(linearLayoutManager);
            RSAdapter rvAdapter = new RSAdapter(data);
            rvRS.setAdapter(rvAdapter);
        }

        @Override
        public void onFailed(String msg) {
            Log.d("ISI ERROR", msg);
        }
    };

}