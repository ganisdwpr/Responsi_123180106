package com.example.pikobar.Adapter;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pikobar.R;
import com.example.pikobar.Models.Kasus.KasusContent;

import java.util.Collections;
import java.util.List;

public class KasusAdapter extends RecyclerView.Adapter<KasusAdapter.ViewHolder> {

    List<KasusContent> item;

    public KasusAdapter(List<KasusContent> item) {
        Collections.reverse(item);
        this.item = item;
    }

    @NonNull
    @Override
    public KasusAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.row_kasus, parent, false);
        return new ViewHolder(view);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_Tanggal, tv_Sembuh, tv_Meninggal, tv_Konfirmasi;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_Tanggal = itemView.findViewById(R.id.tv_tanggal);
            tv_Sembuh = itemView.findViewById(R.id.tv_sembuh);
            tv_Meninggal = itemView.findViewById(R.id.tv_meninggal);
            tv_Konfirmasi = itemView.findViewById(R.id.tv_konfirmasi);
        }

        @SuppressLint("SetTextI18n")
        public void bind(KasusContent kasusContent) {
            tv_Tanggal.setText(kasusContent.getTanggal());
            tv_Sembuh.setText(String.valueOf(kasusContent.getConfirmationSelesai()));
            tv_Meninggal.setText(String.valueOf(kasusContent.getConfirmationMeninggal()));
            tv_Konfirmasi.setText(String.valueOf(kasusContent.getConfirmationDiisolasi()));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull KasusAdapter.ViewHolder holder, int position) {
        holder.bind(item.get(position));
    }

    @Override
    public int getItemCount() {
        return item.size();
    }
}
