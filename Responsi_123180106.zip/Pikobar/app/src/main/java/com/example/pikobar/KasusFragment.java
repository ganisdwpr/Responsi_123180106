package com.example.pikobar;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pikobar.API.ApiListener;
import com.example.pikobar.API.ApiService;
import com.example.pikobar.Adapter.KasusAdapter;
import com.example.pikobar.Models.Kasus.KasusContent;

import java.util.ArrayList;
import java.util.List;

public class KasusFragment extends Fragment {

    RecyclerView rvKasus;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_kasus, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rvKasus = view.findViewById(R.id.rvKasus);
        new ApiService().getKasus(kasusListener);
    }
    ApiListener<List<KasusContent>> kasusListener = new ApiListener<List<KasusContent>>(){

        @Override
        public void onSuccess(List<KasusContent> items) {
            ArrayList<KasusContent> data = new ArrayList<>();
            for(int i = 0; i < items.size(); i++){
                if(!items.get(i).getTanggal().contains("Qualifying")){
                    data.add(items.get(i));
                }
                Log.d("Tanggal : ", items.get(i).getTanggal());
            }

            final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
            linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            rvKasus.setLayoutManager(linearLayoutManager);
            KasusAdapter rvAdapter = new KasusAdapter(data);
            rvKasus.setAdapter(rvAdapter);
        }

        @Override
        public void onFailed(String msg) {
            Log.d("ERROR!", msg);
        }
    };
}