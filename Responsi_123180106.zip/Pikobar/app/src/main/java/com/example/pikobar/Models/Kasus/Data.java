package com.example.pikobar.Models.Kasus;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class Data{

	@SerializedName("metadata")
	private Metadata metadata;

	@SerializedName("content")
	private List<KasusContent> content;

	public void setMetadata(Metadata metadata){
		this.metadata = metadata;
	}

	public Metadata getMetadata(){
		return metadata;
	}

	public void setContent(List<KasusContent> content){
		this.content = content;
	}

	public List<KasusContent> getContent(){
		return content;
	}
}