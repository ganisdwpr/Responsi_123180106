package com.example.pikobar.API;

import com.example.pikobar.Models.Kasus.KasusContent;
import com.example.pikobar.Models.Kasus.KasusRespons;
import com.example.pikobar.Models.RS.RSContent;
import com.example.pikobar.Models.RS.RSRespons;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiService {

    private Retrofit retrofit;

    private static final String URL_BASE = "https://covid19-public.digitalservice.id";
    public ApiInterface getAPI(){
        if (retrofit == null){
            retrofit = new Retrofit
                    .Builder()
                    .baseUrl(URL_BASE)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit.create(ApiInterface.class);
    }

    public void getKasus(final ApiListener<List<KasusContent>> listener){
        getAPI().getKasus().enqueue(new Callback<KasusRespons>() {
            @Override
            public void onResponse(Call<KasusRespons> call, Response<KasusRespons> response) {
                KasusRespons data = response.body();
                if(data != null && data.getData() != null){
                    listener.onSuccess(data.getData().getContent());
                }
            }

            @Override
            public void onFailure(Call<KasusRespons> call, Throwable t) {
                listener.onFailed(t.getMessage());
            }
        });
    }

    public void getRS(final ApiListener<List<RSContent>> listener){
        getAPI().getRS().enqueue(new Callback<RSRespons>() {
            @Override
            public void onResponse(Call<RSRespons> call, Response<RSRespons> response) {
                RSRespons data = response.body();
                if(data != null && data.getData() != null){
                    listener.onSuccess(data.getData());
                }
            }

            @Override
            public void onFailure(Call<RSRespons> call, Throwable t) {
                listener.onFailed(t.getMessage());
            }
        });
    }
}
