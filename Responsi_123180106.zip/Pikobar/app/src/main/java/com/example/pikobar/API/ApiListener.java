package com.example.pikobar.API;

public interface ApiListener<T> {

    void onSuccess(T items);

    void onFailed(String msg);
}
