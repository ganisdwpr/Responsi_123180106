package com.example.pikobar.Models.RS;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class RSRespons {

	@SerializedName("status_code")
	private int statusCode;

	@SerializedName("data")
	private List<RSContent> data;

	public void setStatusCode(int statusCode){
		this.statusCode = statusCode;
	}

	public int getStatusCode(){
		return statusCode;
	}

	public void setData(List<RSContent> data){
		this.data = data;
	}

	public List<RSContent> getData(){
		return data;
	}
}