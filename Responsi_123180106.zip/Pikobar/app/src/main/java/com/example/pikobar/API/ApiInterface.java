package com.example.pikobar.API;

import com.example.pikobar.Models.Kasus.KasusRespons;
import com.example.pikobar.Models.RS.RSRespons;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {

    @GET("/api/v1/rekapitulasi_v2/jabar/harian")
    Call<KasusRespons> getKasus();

    @GET("/api/v1/sebaran_v2/jabar/faskes")
    Call<RSRespons> getRS();
}
